```python
import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns 
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.preprocessing import StandardScaler
```


```python
data = pd.read_excel(r"C:\Users\HP\Downloads\Personal Style Trend Analysis Survey.xlsx")
print(data)
```

                     Timestamp        How would you define your current style ?    \
    0  2024-11-06 09:45:04.592                                             Casual   
    1  2024-11-06 13:36:13.966                                             Casual   
    2  2024-11-05 22:28:40.934                                             Casual   
    3  2024-11-05 22:29:19.966                        Casual, Professional, Other   
    4  2024-11-05 22:29:34.558                        Casual, Streetwear, Classic   
    5  2024-11-07 10:58:54.856                                 Casual, Streetwear   
    6  2024-11-06 10:15:35.155                   Casual, Streetwear, Professional   
    7  2024-11-05 22:30:58.779                                             Casual   
    8  2024-11-06 11:09:29.200                                            Classic   
    9  2024-11-05 22:45:02.853                                             Casual   
    10 2024-11-05 22:45:07.707                            Casual, Classic, Sporty   
    11 2024-11-05 22:51:04.705                               Casual, Professional   
    12 2024-11-06 10:52:26.073                                             Casual   
    13 2024-11-05 23:19:17.299                      Casual, Professional, Classic   
    14 2024-11-06 00:11:15.651                              Professional, Classic   
    15 2024-11-06 00:16:50.411                                             Sporty   
    16 2024-11-06 10:35:23.336                                             Casual   
    17 2024-11-06 08:53:49.074                                             Casual   
    18 2024-11-06 08:56:37.800                                             Casual   
    19 2024-11-06 09:47:59.390                                       Professional   
    20 2024-11-06 09:52:38.438  Casual, Streetwear, Professional, Classic, Sporty   
    21 2024-11-06 10:05:28.803                                             Casual   
    22 2024-11-06 10:07:42.176                                       Professional   
    23 2024-11-06 10:23:54.237                                       Professional   
    24 2024-11-06 10:26:34.745                                             Casual   
    25 2024-11-06 10:27:05.094                                             Casual   
    26 2024-11-06 10:34:34.221                                             Casual   
    27 2024-11-06 10:59:03.880                                             Casual   
    28 2024-11-06 11:06:45.464                                         Streetwear   
    29 2024-11-06 12:06:04.063                       Casual, Professional, Sporty   
    30 2024-11-06 13:04:21.962                                             Casual   
    31 2024-11-06 13:07:53.529                                             Sporty   
    32 2024-11-06 13:33:15.399                                             Casual   
    33 2024-11-06 13:41:47.622                                     Casual, Sporty   
    34 2024-11-06 15:40:24.461                                             Casual   
    35 2024-11-06 16:13:33.481                                             Casual   
    36 2024-11-06 20:24:38.076                                             Casual   
    37 2024-11-06 20:42:11.581                                       Professional   
    38 2024-11-06 21:23:07.439                                    Casual, Classic   
    39 2024-11-07 10:45:48.482                               Casual, Professional   
    40 2024-11-07 10:47:06.465                                            Classic   
    41 2024-11-07 11:10:03.827                                       Professional   
    42 2024-11-07 23:21:09.596                                             Casual   
    
         How often do you buy new clothes or accessories ?    \
    0                                    Every few months      
    1                                             Monthly      
    2                                    Every few months      
    3                                    Every few months      
    4                                    Every few months      
    5                                    Every few months      
    6                                             Monthly      
    7                                    Every few months      
    8                                              Rarely      
    9                                    Every few months      
    10                                            Monthly      
    11                                   Every few months      
    12                                   Every few months      
    13                                            Monthly      
    14                                   Every few months      
    15                                   Every few months      
    16                                   Every few months      
    17                                            Monthly      
    18                                   Every few months      
    19                                   Every few months      
    20                                             Rarely      
    21                                             Rarely      
    22                                             Weekly      
    23                                            Monthly      
    24                                            Monthly      
    25                                            Monthly      
    26                                   Every few months      
    27                                             Rarely      
    28                                            Monthly      
    29                                   Every few months      
    30                                   Every few months      
    31                                             Rarely      
    32                                             Weekly      
    33                                            Monthly      
    34                                             Rarely      
    35                                   Every few months      
    36                                   Every few months      
    37                                            Monthly      
    38                                   Every few months      
    39                                   Every few months      
    40                                            Monthly      
    41                                            Monthly      
    42                                   Every few months      
    
       What are your go-to clothing colors ?   \
    0                                 Neutral   
    1                                 Brights   
    2                                 Pastels   
    3                                 Neutral   
    4                                 Neutral   
    5                                 Pastels   
    6                          Mixed Patterns   
    7                                 Neutral   
    8                                 Neutral   
    9                              Dark Tones   
    10                                Pastels   
    11                                Brights   
    12                             Dark Tones   
    13                             Dark Tones   
    14                             Dark Tones   
    15                             Dark Tones   
    16                                Neutral   
    17                         Mixed Patterns   
    18                                Neutral   
    19                                Neutral   
    20                                Neutral   
    21                         Mixed Patterns   
    22                                Brights   
    23                             Dark Tones   
    24                                Neutral   
    25                                Neutral   
    26                                Neutral   
    27                                Brights   
    28                         Mixed Patterns   
    29                         Mixed Patterns   
    30                             Dark Tones   
    31                         Mixed Patterns   
    32                         Mixed Patterns   
    33                             Dark Tones   
    34                                Brights   
    35                         Mixed Patterns   
    36                                Neutral   
    37                                Brights   
    38                             Dark Tones   
    39                                Neutral   
    40                             Dark Tones   
    41                                Pastels   
    42                                Neutral   
    
       Which elements do you feel contribute most to your favorite outfits ?   \
    0                        Uniqueness or Personal Style                       
    1                                     Celebrity Style                       
    2                        Uniqueness or Personal Style                       
    3                                Quality And Material                       
    4                        Uniqueness or Personal Style                       
    5                                Quality And Material                       
    6                                     Fit and Comfort                       
    7                                          Trendlines                       
    8                        Uniqueness or Personal Style                       
    9                                Quality And Material                       
    10                               Quality And Material                       
    11                                    Fit and Comfort                       
    12                               Quality And Material                       
    13                       Uniqueness or Personal Style                       
    14                               Quality And Material                       
    15                                    Fit and Comfort                       
    16                                    Fit and Comfort                       
    17                                         Trendlines                       
    18                                    Fit and Comfort                       
    19                               Quality And Material                       
    20                                    Fit and Comfort                       
    21                                    Fit and Comfort                       
    22                               Quality And Material                       
    23                       Uniqueness or Personal Style                       
    24                               Quality And Material                       
    25                                    Celebrity Style                       
    26                                         Trendlines                       
    27                               Quality And Material                       
    28                       Uniqueness or Personal Style                       
    29                                    Fit and Comfort                       
    30                                         Trendlines                       
    31                               Quality And Material                       
    32                                    Fit and Comfort                       
    33                                    Fit and Comfort                       
    34                                         Trendlines                       
    35                                    Fit and Comfort                       
    36                       Uniqueness or Personal Style                       
    37                                    Fit and Comfort                       
    38                                    Fit and Comfort                       
    39                                                NaN                       
    40                                                NaN                       
    41                                                NaN                       
    42                                                NaN                       
    
       Which elements do you feel contribute most to your favorite outfits ? .1  \
    0                                     Celebrity Style                         
    1                                     Fit and Comfort                         
    2                             Color or Personal Style                         
    3                                Quality And Material                         
    4                                          Trendlines                         
    5                                     Fit and Comfort                         
    6                             Color or Personal Style                         
    7                                          Trendlines                         
    8                                Quality And Material                         
    9                                Quality And Material                         
    10                            Color or Personal Style                         
    11                            Color or Personal Style                         
    12                               Quality And Material                         
    13                               Quality And Material                         
    14                               Quality And Material                         
    15                            Color or Personal Style                         
    16                               Quality And Material                         
    17                                    Celebrity Style                         
    18                            Color or Personal Style                         
    19                            Color or Personal Style                         
    20                                    Fit and Comfort                         
    21                                    Fit and Comfort                         
    22                            Color or Personal Style                         
    23                            Color or Personal Style                         
    24                               Quality And Material                         
    25                                    Celebrity Style                         
    26                                         Trendlines                         
    27                            Color or Personal Style                         
    28                                         Trendlines                         
    29                               Quality And Material                         
    30                            Color or Personal Style                         
    31                               Quality And Material                         
    32                                    Fit and Comfort                         
    33                            Color or Personal Style                         
    34                               Quality And Material                         
    35                               Quality And Material                         
    36                                    Fit and Comfort                         
    37                               Quality And Material                         
    38                               Quality And Material                         
    39                            Color or Personal Style                         
    40                               Quality And Material                         
    41                                    Fit and Comfort                         
    42                                         Trendlines                         
    
         Which types of clothing do you wear most often ?    \
    0                                   Dresses or Skirts     
    1                                    Jeans & T-shirts     
    2                                    Jeans & T-shirts     
    3                                    Jeans & T-shirts     
    4                                    Jeans & T-shirts     
    5                                   Dresses or Skirts     
    6                                    Jeans & T-shirts     
    7                                    Jeans & T-shirts     
    8                              Other (Please Specify)     
    9                                    Jeans & T-shirts     
    10                                              Suits     
    11                                   Jeans & T-shirts     
    12                                   Jeans & T-shirts     
    13                                   Jeans & T-shirts     
    14                                   Jeans & T-shirts     
    15                                   Jeans & T-shirts     
    16                                   Jeans & T-shirts     
    17                                             Sarees     
    18                                   Jeans & T-shirts     
    19                                   Jeans & T-shirts     
    20                                   Jeans & T-shirts     
    21                                   Jeans & T-shirts     
    22                                   Jeans & T-shirts     
    23                             Other (Please Specify)     
    24                                   Jeans & T-shirts     
    25                                   Jeans & T-shirts     
    26                                   Jeans & T-shirts     
    27                             Other (Please Specify)     
    28                                  Dresses or Skirts     
    29                                   Jeans & T-shirts     
    30                                             Sarees     
    31                                   Jeans & T-shirts     
    32                                   Jeans & T-shirts     
    33                                   Jeans & T-shirts     
    34                                   Jeans & T-shirts     
    35                                   Jeans & T-shirts     
    36                                   Jeans & T-shirts     
    37                                   Jeans & T-shirts     
    38                                   Jeans & T-shirts     
    39                           Formals Shirts and Pants     
    40                                   Jeans & T-shirts     
    41                                   Jeans & T-shirts     
    42                                   Jeans & T-shirts     
    
       How do you feel about your current style choices ?   \
    0                 Unsatisfied, I want to make changes    
    1                 Neutral, I’m unsure if they suit me    
    2                 Unsatisfied, I want to make changes    
    3      Mostly satisfied, but I’d like to explore more    
    4      Mostly satisfied, but I’d like to explore more    
    5      Mostly satisfied, but I’d like to explore more    
    6      Mostly satisfied, but I’d like to explore more    
    7      Mostly satisfied, but I’d like to explore more    
    8         Very satisfied, I feel they reflect me well    
    9         Very satisfied, I feel they reflect me well    
    10        Very satisfied, I feel they reflect me well    
    11        Very satisfied, I feel they reflect me well    
    12        Very satisfied, I feel they reflect me well    
    13        Very satisfied, I feel they reflect me well    
    14        Very satisfied, I feel they reflect me well    
    15     Mostly satisfied, but I’d like to explore more    
    16                Neutral, I’m unsure if they suit me    
    17     Mostly satisfied, but I’d like to explore more    
    18        Very satisfied, I feel they reflect me well    
    19                Neutral, I’m unsure if they suit me    
    20     Mostly satisfied, but I’d like to explore more    
    21     Mostly satisfied, but I’d like to explore more    
    22                Neutral, I’m unsure if they suit me    
    23        Very satisfied, I feel they reflect me well    
    24                Neutral, I’m unsure if they suit me    
    25                Neutral, I’m unsure if they suit me    
    26     Mostly satisfied, but I’d like to explore more    
    27                Neutral, I’m unsure if they suit me    
    28        Very satisfied, I feel they reflect me well    
    29        Very satisfied, I feel they reflect me well    
    30     Mostly satisfied, but I’d like to explore more    
    31     Mostly satisfied, but I’d like to explore more    
    32     Mostly satisfied, but I’d like to explore more    
    33     Mostly satisfied, but I’d like to explore more    
    34     Mostly satisfied, but I’d like to explore more    
    35        Very satisfied, I feel they reflect me well    
    36     Mostly satisfied, but I’d like to explore more    
    37     Mostly satisfied, but I’d like to explore more    
    38     Mostly satisfied, but I’d like to explore more    
    39        Very satisfied, I feel they reflect me well    
    40     Mostly satisfied, but I’d like to explore more    
    41        Very satisfied, I feel they reflect me well    
    42                Neutral, I’m unsure if they suit me    
    
         What factors influence your clothing purchases the most ?    \
    0                                               Price              
    1                                             Quality              
    2                                               Style              
    3                                    Brand reputation              
    4                                    Brand reputation              
    5                                             Quality              
    6                                             Quality              
    7                                               Style              
    8                                               Style              
    9                                             Quality              
    10                                            Quality              
    11                                            Quality              
    12                                            Quality              
    13                                   Brand reputation              
    14                                              Style              
    15                                              Price              
    16                                   Brand reputation              
    17                                              Style              
    18                                            Quality              
    19                                            Quality              
    20                                            Quality              
    21                                            Quality              
    22                                            Quality              
    23                                              Style              
    24                                            Quality              
    25                                            Quality              
    26                                              Price              
    27                                              Price              
    28                                            Quality              
    29                                            Quality              
    30                                              Style              
    31                                   Brand reputation              
    32                                            Quality              
    33                                            Quality              
    34                                            Quality              
    35                                            Quality              
    36                                            Quality              
    37                                              Style              
    38                                            Quality              
    39                                            Quality              
    40                                            Quality              
    41                                            Quality              
    42                                            Quality              
    
         How much do you spend on clothing each month on average ?    \
    0                                      1000-2000 Rs/-              
    1                                               2000+              
    2                                       500-1000 Rs/-              
    3                                               2000+              
    4                                       500-1000 Rs/-              
    5                                       500-1000 Rs/-              
    6                                       500-1000 Rs/-              
    7                                               2000+              
    8                                       200 -500 Rs/-              
    9                                               2000+              
    10                                     1000-2000 Rs/-              
    11                                     1000-2000 Rs/-              
    12                                     1000-2000 Rs/-              
    13                                      500-1000 Rs/-              
    14                                     1000-2000 Rs/-              
    15                                      500-1000 Rs/-              
    16                                      500-1000 Rs/-              
    17                                      500-1000 Rs/-              
    18                                      500-1000 Rs/-              
    19                                     1000-2000 Rs/-              
    20                                      200 -500 Rs/-              
    21                                      200 -500 Rs/-              
    22                                      500-1000 Rs/-              
    23                                      500-1000 Rs/-              
    24                                     1000-2000 Rs/-              
    25                                              2000+              
    26                                      200 -500 Rs/-              
    27                                      500-1000 Rs/-              
    28                                     1000-2000 Rs/-              
    29                                     1000-2000 Rs/-              
    30                                      500-1000 Rs/-              
    31                                     1000-2000 Rs/-              
    32                                     1000-2000 Rs/-              
    33                                     1000-2000 Rs/-              
    34                                      500-1000 Rs/-              
    35                                              2000+              
    36                                      500-1000 Rs/-              
    37                                              2000+              
    38                                      500-1000 Rs/-              
    39                                     1000-2000 Rs/-              
    40                                              2000+              
    41                                      500-1000 Rs/-              
    42                                      500-1000 Rs/-              
    
         Do you prefer online or in-store shopping for clothes ?    \
    0                                     Mostly In-store            
    1                                        Both Equally            
    2                                        Both Equally            
    3                                        Both Equally            
    4                                       Mostly online            
    5                                       Mostly online            
    6                                        Both Equally            
    7                                     Mostly In-store            
    8                                       Mostly online            
    9                                        Both Equally            
    10                                       Both Equally            
    11                                      Mostly online            
    12                                       Both Equally            
    13                                       Both Equally            
    14                                      Mostly online            
    15                                      Mostly online            
    16                                      Mostly online            
    17                                       Both Equally            
    18                                    Mostly In-store            
    19                                    Mostly In-store            
    20                                      Mostly online            
    21                                    Mostly In-store            
    22                                    Mostly In-store            
    23                                       Both Equally            
    24                                      Mostly online            
    25                                    Mostly In-store            
    26                                    Mostly In-store            
    27                                    Mostly In-store            
    28                                       Both Equally            
    29                                       Both Equally            
    30                                      Mostly online            
    31                                       Both Equally            
    32                                    Mostly In-store            
    33                                       Both Equally            
    34                                      Mostly online            
    35                                    Mostly In-store            
    36                                    Mostly In-store            
    37                                       Both Equally            
    38                                       Both Equally            
    39                                      Mostly online            
    40                                    Mostly In-store            
    41                                       Both Equally            
    42                                       Both Equally            
    
       "How often do you feel confident in your outfits ?   \
    0                                              Rarely    
    1                                        Occasionally    
    2                                               Often    
    3                                    Almost every day    
    4                                        Occasionally    
    5                                    Almost every day    
    6                                               Often    
    7                                               Often    
    8                                    Almost every day    
    9                                    Almost every day    
    10                                   Almost every day    
    11                                   Almost every day    
    12                                   Almost every day    
    13                                   Almost every day    
    14                                   Almost every day    
    15                                   Almost every day    
    16                                              Often    
    17                                   Almost every day    
    18                                   Almost every day    
    19                                       Occasionally    
    20                                   Almost every day    
    21                                   Almost every day    
    22                                              Often    
    23                                              Often    
    24                                       Occasionally    
    25                                   Almost every day    
    26                                              Often    
    27                                             Rarely    
    28                                   Almost every day    
    29                                   Almost every day    
    30                                       Occasionally    
    31                                   Almost every day    
    32                                   Almost every day    
    33                                   Almost every day    
    34                                       Occasionally    
    35                                       Occasionally    
    36                                   Almost every day    
    37                                       Occasionally    
    38                                   Almost every day    
    39                                              Often    
    40                                              Often    
    41                                       Occasionally    
    42                                   Almost every day    
    
         What is your primary goal for improving your personal style?    \
    0               To focus on comfort and functionality                 
    1                               To explore new trends                 
    2                               To explore new trends                 
    3             To feel more confident in my appearance                 
    4             To feel more confident in my appearance                 
    5             To feel more confident in my appearance                 
    6             To feel more confident in my appearance                 
    7             To feel more confident in my appearance                 
    8             To feel more confident in my appearance                 
    9             To feel more confident in my appearance                 
    10              To focus on comfort and functionality                 
    11            To feel more confident in my appearance                 
    12                   To better express my personality                 
    13              To focus on comfort and functionality                 
    14                   To better express my personality                 
    15                   To better express my personality                 
    16                   To better express my personality                 
    17                              To explore new trends                 
    18            To feel more confident in my appearance                 
    19            To feel more confident in my appearance                 
    20            To feel more confident in my appearance                 
    21            To feel more confident in my appearance                 
    22                              To explore new trends                 
    23              To focus on comfort and functionality                 
    24              To focus on comfort and functionality                 
    25                              To explore new trends                 
    26            To feel more confident in my appearance                 
    27                   To better express my personality                 
    28            To feel more confident in my appearance                 
    29            To feel more confident in my appearance                 
    30            To feel more confident in my appearance                 
    31                              To explore new trends                 
    32              To focus on comfort and functionality                 
    33            To feel more confident in my appearance                 
    34            To feel more confident in my appearance                 
    35                              To explore new trends                 
    36                              To explore new trends                 
    37              To focus on comfort and functionality                 
    38            To feel more confident in my appearance                 
    39                   To better express my personality                 
    40            To feel more confident in my appearance                 
    41              To focus on comfort and functionality                 
    42            To feel more confident in my appearance                 
    
                 Full Name    Age  Gender   Column 15  Gender  
    0                   Jay  18-25    Male        NaN     NaN  
    1          Sachin yede   18-25    Male        NaN     NaN  
    2               Avinash  25-30    Male        NaN     NaN  
    3           Ayush singh  25-30    Male        NaN     NaN  
    4       Bhuvnesh Thakur  18-25    Male        NaN     NaN  
    5        Nimisha Sinha   18-25  Female        NaN     NaN  
    6                Prachi  18-25  Female        NaN     NaN  
    7         Ayesha Sharma  18-25  Female        NaN     NaN  
    8   Ram Krishna Pandey   18-25    Male        NaN     NaN  
    9       Chaulesh Gautam  18-25   Male         NaN     NaN  
    10           Isha Arora  18-25  Female        NaN     NaN  
    11         Sumit Swayam  25-30    Male        NaN     NaN  
    12          Vishal Roy   18-25    Male        NaN     NaN  
    13           Ayush Soni  18-25    Male        NaN     NaN  
    14          Avant Kumar  25-30    Male        NaN     NaN  
    15         Raman Mishra  18-25    Male        NaN     NaN  
    16       Himanshu Kumar  18-25    Male        NaN     NaN  
    17       Manisha Hanvat  25-30  Female        NaN     NaN  
    18         Hemant Kumar  25-30    Male        NaN     NaN  
    19      Shivanee Dixit   18-25  Female        NaN     NaN  
    20             Kaushik   18-25    Male        NaN     NaN  
    21             Himanshi  18-25  Female        NaN     NaN  
    22               Nitish  18-25    Male        NaN     NaN  
    23                Karan  18-25    Male        NaN     NaN  
    24              Rishabh  18-25    Male        NaN     NaN  
    25        sweety kumari  18-25  Female        NaN     NaN  
    26        Trisha Biswas  18-25  Female        NaN     NaN  
    27     Rishabh randive   18-25    Male        NaN     NaN  
    28               Karina  18-25  Female        NaN     NaN  
    29     Rishabh Katiyar   18-25    Male        NaN     NaN  
    30    Nisha rahangdale   25-30  Female        NaN     NaN  
    31   Manish rahangdale   25-30    Male        NaN     NaN  
    32        Prakhar Gupta  18-25    Male        NaN     NaN  
    33         Tarun kumar   18-25    Male        NaN     NaN  
    34         Nitesh kumar  18-25    Male        NaN     NaN  
    35      Pratik Salgude   18-25    Male        NaN     NaN  
    36               Avinav  18-25    Male        NaN     NaN  
    37                Reena  18-25  Female        NaN     NaN  
    38     shambhavi kumari  18-25  Female        NaN     NaN  
    39            Rohit Das  18-25    Male        NaN     NaN  
    40         Qadir Husain  18-25    Male        NaN     NaN  
    41       Anshu Tripathi  18-25    Male        NaN     NaN  
    42          Swati Priya  18-25  Female        NaN     NaN  
    


```python
data.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Timestamp</th>
      <th>How would you define your current style ?</th>
      <th>How often do you buy new clothes or accessories ?</th>
      <th>What are your go-to clothing colors ?</th>
      <th>Which elements do you feel contribute most to your favorite outfits ?</th>
      <th>Which elements do you feel contribute most to your favorite outfits ? .1</th>
      <th>Which types of clothing do you wear most often ?</th>
      <th>How do you feel about your current style choices ?</th>
      <th>What factors influence your clothing purchases the most ?</th>
      <th>How much do you spend on clothing each month on average ?</th>
      <th>Do you prefer online or in-store shopping for clothes ?</th>
      <th>"How often do you feel confident in your outfits ?</th>
      <th>What is your primary goal for improving your personal style?</th>
      <th>Full Name</th>
      <th>Age</th>
      <th>Gender</th>
      <th>Column 15</th>
      <th>Gender</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2024-11-06 09:45:04.592</td>
      <td>Casual</td>
      <td>Every few months</td>
      <td>Neutral</td>
      <td>Uniqueness or Personal Style</td>
      <td>Celebrity Style</td>
      <td>Dresses or Skirts</td>
      <td>Unsatisfied, I want to make changes</td>
      <td>Price</td>
      <td>1000-2000 Rs/-</td>
      <td>Mostly In-store</td>
      <td>Rarely</td>
      <td>To focus on comfort and functionality</td>
      <td>Jay</td>
      <td>18-25</td>
      <td>Male</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2024-11-06 13:36:13.966</td>
      <td>Casual</td>
      <td>Monthly</td>
      <td>Brights</td>
      <td>Celebrity Style</td>
      <td>Fit and Comfort</td>
      <td>Jeans &amp; T-shirts</td>
      <td>Neutral, I’m unsure if they suit me</td>
      <td>Quality</td>
      <td>2000+</td>
      <td>Both Equally</td>
      <td>Occasionally</td>
      <td>To explore new trends</td>
      <td>Sachin yede</td>
      <td>18-25</td>
      <td>Male</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2024-11-05 22:28:40.934</td>
      <td>Casual</td>
      <td>Every few months</td>
      <td>Pastels</td>
      <td>Uniqueness or Personal Style</td>
      <td>Color or Personal Style</td>
      <td>Jeans &amp; T-shirts</td>
      <td>Unsatisfied, I want to make changes</td>
      <td>Style</td>
      <td>500-1000 Rs/-</td>
      <td>Both Equally</td>
      <td>Often</td>
      <td>To explore new trends</td>
      <td>Avinash</td>
      <td>25-30</td>
      <td>Male</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2024-11-05 22:29:19.966</td>
      <td>Casual, Professional, Other</td>
      <td>Every few months</td>
      <td>Neutral</td>
      <td>Quality And Material</td>
      <td>Quality And Material</td>
      <td>Jeans &amp; T-shirts</td>
      <td>Mostly satisfied, but I’d like to explore more</td>
      <td>Brand reputation</td>
      <td>2000+</td>
      <td>Both Equally</td>
      <td>Almost every day</td>
      <td>To feel more confident in my appearance</td>
      <td>Ayush singh</td>
      <td>25-30</td>
      <td>Male</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2024-11-05 22:29:34.558</td>
      <td>Casual, Streetwear, Classic</td>
      <td>Every few months</td>
      <td>Neutral</td>
      <td>Uniqueness or Personal Style</td>
      <td>Trendlines</td>
      <td>Jeans &amp; T-shirts</td>
      <td>Mostly satisfied, but I’d like to explore more</td>
      <td>Brand reputation</td>
      <td>500-1000 Rs/-</td>
      <td>Mostly online</td>
      <td>Occasionally</td>
      <td>To feel more confident in my appearance</td>
      <td>Bhuvnesh Thakur</td>
      <td>18-25</td>
      <td>Male</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
data.tail(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Timestamp</th>
      <th>How would you define your current style ?</th>
      <th>How often do you buy new clothes or accessories ?</th>
      <th>What are your go-to clothing colors ?</th>
      <th>Which elements do you feel contribute most to your favorite outfits ?</th>
      <th>Which elements do you feel contribute most to your favorite outfits ? .1</th>
      <th>Which types of clothing do you wear most often ?</th>
      <th>How do you feel about your current style choices ?</th>
      <th>What factors influence your clothing purchases the most ?</th>
      <th>How much do you spend on clothing each month on average ?</th>
      <th>Do you prefer online or in-store shopping for clothes ?</th>
      <th>"How often do you feel confident in your outfits ?</th>
      <th>What is your primary goal for improving your personal style?</th>
      <th>Full Name</th>
      <th>Age</th>
      <th>Gender</th>
      <th>Column 15</th>
      <th>Gender</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>38</th>
      <td>2024-11-06 21:23:07.439</td>
      <td>Casual, Classic</td>
      <td>Every few months</td>
      <td>Dark Tones</td>
      <td>Fit and Comfort</td>
      <td>Quality And Material</td>
      <td>Jeans &amp; T-shirts</td>
      <td>Mostly satisfied, but I’d like to explore more</td>
      <td>Quality</td>
      <td>500-1000 Rs/-</td>
      <td>Both Equally</td>
      <td>Almost every day</td>
      <td>To feel more confident in my appearance</td>
      <td>shambhavi kumari</td>
      <td>18-25</td>
      <td>Female</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>39</th>
      <td>2024-11-07 10:45:48.482</td>
      <td>Casual, Professional</td>
      <td>Every few months</td>
      <td>Neutral</td>
      <td>NaN</td>
      <td>Color or Personal Style</td>
      <td>Formals Shirts and Pants</td>
      <td>Very satisfied, I feel they reflect me well</td>
      <td>Quality</td>
      <td>1000-2000 Rs/-</td>
      <td>Mostly online</td>
      <td>Often</td>
      <td>To better express my personality</td>
      <td>Rohit Das</td>
      <td>18-25</td>
      <td>Male</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>40</th>
      <td>2024-11-07 10:47:06.465</td>
      <td>Classic</td>
      <td>Monthly</td>
      <td>Dark Tones</td>
      <td>NaN</td>
      <td>Quality And Material</td>
      <td>Jeans &amp; T-shirts</td>
      <td>Mostly satisfied, but I’d like to explore more</td>
      <td>Quality</td>
      <td>2000+</td>
      <td>Mostly In-store</td>
      <td>Often</td>
      <td>To feel more confident in my appearance</td>
      <td>Qadir Husain</td>
      <td>18-25</td>
      <td>Male</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>41</th>
      <td>2024-11-07 11:10:03.827</td>
      <td>Professional</td>
      <td>Monthly</td>
      <td>Pastels</td>
      <td>NaN</td>
      <td>Fit and Comfort</td>
      <td>Jeans &amp; T-shirts</td>
      <td>Very satisfied, I feel they reflect me well</td>
      <td>Quality</td>
      <td>500-1000 Rs/-</td>
      <td>Both Equally</td>
      <td>Occasionally</td>
      <td>To focus on comfort and functionality</td>
      <td>Anshu Tripathi</td>
      <td>18-25</td>
      <td>Male</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>42</th>
      <td>2024-11-07 23:21:09.596</td>
      <td>Casual</td>
      <td>Every few months</td>
      <td>Neutral</td>
      <td>NaN</td>
      <td>Trendlines</td>
      <td>Jeans &amp; T-shirts</td>
      <td>Neutral, I’m unsure if they suit me</td>
      <td>Quality</td>
      <td>500-1000 Rs/-</td>
      <td>Both Equally</td>
      <td>Almost every day</td>
      <td>To feel more confident in my appearance</td>
      <td>Swati Priya</td>
      <td>18-25</td>
      <td>Female</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
data.notnull()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Timestamp</th>
      <th>How would you define your current style ?</th>
      <th>How often do you buy new clothes or accessories ?</th>
      <th>What are your go-to clothing colors ?</th>
      <th>Which elements do you feel contribute most to your favorite outfits ?</th>
      <th>Which elements do you feel contribute most to your favorite outfits ? .1</th>
      <th>Which types of clothing do you wear most often ?</th>
      <th>How do you feel about your current style choices ?</th>
      <th>What factors influence your clothing purchases the most ?</th>
      <th>How much do you spend on clothing each month on average ?</th>
      <th>Do you prefer online or in-store shopping for clothes ?</th>
      <th>"How often do you feel confident in your outfits ?</th>
      <th>What is your primary goal for improving your personal style?</th>
      <th>Full Name</th>
      <th>Age</th>
      <th>Gender</th>
      <th>Column 15</th>
      <th>Gender</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>1</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>3</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>4</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>5</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>6</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>7</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>8</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>9</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>10</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>11</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>12</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>13</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>14</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>15</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>16</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>17</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>18</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>19</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>20</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>21</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>22</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>23</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>24</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>25</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>26</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>27</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>28</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>29</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>30</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>31</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>32</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>33</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>34</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>35</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>36</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>37</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>38</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>39</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>40</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>41</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>42</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
  </tbody>
</table>
</div>




```python
df = pd.DataFrame(data)
```


```python
# Set Seaborn style
sns.set_style('whitegrid')
```


```python
# Inspect column names and adjust the renaming accordingly
data.columns = [
    "Timestamp",
    "Current_Style",
    "Buying_Frequency",
    "Favorite_Colors",
    "Favorite_Outfit_Element1",
    "Favorite_Outfit_Element2",
    "Common_Clothing_Type",
    "Style_Satisfaction",
    "Purchase_Influences",
    "Monthly_Spending",
    "Shopping_Preference",
    "Confidence_Frequency",
    "Style_Improvement_Goal",
    "Full_Name",
    "Age",
    "Gender",
    "Column_17",  # Placeholder for the extra column
    "Column_18",  # Placeholder for another extra column
]
```


```python
# Drop unnecessary columns
data_cleaned = data.drop(columns=["Column_17", "Column_18", "Gender"], errors="ignore")

# Overview of the dataset
print("Dataset Info:")
data_cleaned.info()
print("\nDescriptive Statistics:")
print(data_cleaned.describe(include="all"))
```

    Dataset Info:
    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 43 entries, 0 to 42
    Data columns (total 15 columns):
     #   Column                    Non-Null Count  Dtype         
    ---  ------                    --------------  -----         
     0   Timestamp                 43 non-null     datetime64[ns]
     1   Current_Style             43 non-null     object        
     2   Buying_Frequency          43 non-null     object        
     3   Favorite_Colors           43 non-null     object        
     4   Favorite_Outfit_Element1  39 non-null     object        
     5   Favorite_Outfit_Element2  43 non-null     object        
     6   Common_Clothing_Type      43 non-null     object        
     7   Style_Satisfaction        43 non-null     object        
     8   Purchase_Influences       43 non-null     object        
     9   Monthly_Spending          43 non-null     object        
     10  Shopping_Preference       43 non-null     object        
     11  Confidence_Frequency      43 non-null     object        
     12  Style_Improvement_Goal    43 non-null     object        
     13  Full_Name                 43 non-null     object        
     14  Age                       43 non-null     object        
    dtypes: datetime64[ns](1), object(14)
    memory usage: 5.2+ KB
    
    Descriptive Statistics:
                                Timestamp Current_Style  Buying_Frequency  \
    count                              43            43                43   
    unique                            NaN            17                 4   
    top                               NaN        Casual  Every few months   
    freq                              NaN            20                22   
    mean    2024-11-06 12:12:39.054558464           NaN               NaN   
    min        2024-11-05 22:28:40.934000           NaN               NaN   
    25%     2024-11-06 08:55:13.436999936           NaN               NaN   
    50%     2024-11-06 10:34:34.220999936           NaN               NaN   
    75%     2024-11-06 13:39:00.794000128           NaN               NaN   
    max        2024-11-07 23:21:09.596000           NaN               NaN   
    
           Favorite_Colors Favorite_Outfit_Element1 Favorite_Outfit_Element2  \
    count               43                       39                       43   
    unique               5                        5                        5   
    top            Neutral          Fit and Comfort     Quality And Material   
    freq                15                       13                       15   
    mean               NaN                      NaN                      NaN   
    min                NaN                      NaN                      NaN   
    25%                NaN                      NaN                      NaN   
    50%                NaN                      NaN                      NaN   
    75%                NaN                      NaN                      NaN   
    max                NaN                      NaN                      NaN   
    
           Common_Clothing_Type                              Style_Satisfaction  \
    count                    43                                              43   
    unique                    6                                               4   
    top        Jeans & T-shirts  Mostly satisfied, but I’d like to explore more   
    freq                     33                                              19   
    mean                    NaN                                             NaN   
    min                     NaN                                             NaN   
    25%                     NaN                                             NaN   
    50%                     NaN                                             NaN   
    75%                     NaN                                             NaN   
    max                     NaN                                             NaN   
    
           Purchase_Influences Monthly_Spending Shopping_Preference  \
    count                   43               43                  43   
    unique                   4                4                   3   
    top                Quality    500-1000 Rs/-        Both Equally   
    freq                    26               18                  18   
    mean                   NaN              NaN                 NaN   
    min                    NaN              NaN                 NaN   
    25%                    NaN              NaN                 NaN   
    50%                    NaN              NaN                 NaN   
    75%                    NaN              NaN                 NaN   
    max                    NaN              NaN                 NaN   
    
           Confidence_Frequency                   Style_Improvement_Goal  \
    count                    43                                       43   
    unique                    4                                        4   
    top        Almost every day  To feel more confident in my appearance   
    freq                     23                                       21   
    mean                    NaN                                      NaN   
    min                     NaN                                      NaN   
    25%                     NaN                                      NaN   
    50%                     NaN                                      NaN   
    75%                     NaN                                      NaN   
    max                     NaN                                      NaN   
    
           Full_Name    Age  
    count         43     43  
    unique        43      2  
    top          Jay  18-25  
    freq           1     35  
    mean         NaN    NaN  
    min          NaN    NaN  
    25%          NaN    NaN  
    50%          NaN    NaN  
    75%          NaN    NaN  
    max          NaN    NaN  
    


```python
# Visualization of Current Style
plt.figure(figsize=(10, 6))
sns.countplot(
    y="Current_Style",
    data=data_cleaned,
    order=data_cleaned["Current_Style"].value_counts().index,
    palette="viridis",
)
plt.title("Distribution of Current Style Preferences")
plt.xlabel("Count")
plt.ylabel("Style")
plt.show()
```

    C:\Users\HP\AppData\Local\Temp\ipykernel_12596\4242005910.py:3: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `y` variable to `hue` and set `legend=False` for the same effect.
    
      sns.countplot(
    


    
![png](output_9_1.png)
    



```python
# Visualization of Monthly Spending
plt.figure(figsize=(8, 5))
sns.countplot(
    x="Monthly_Spending",
    data=data_cleaned,
    order=data_cleaned["Monthly_Spending"].value_counts().index,
    palette="coolwarm",
)
plt.title("Monthly Spending on Clothing")
plt.xlabel("Spending Range")
plt.ylabel("Count")
plt.show()
```

    C:\Users\HP\AppData\Local\Temp\ipykernel_12596\3797508258.py:3: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `x` variable to `hue` and set `legend=False` for the same effect.
    
      sns.countplot(
    


    
![png](output_10_1.png)
    



```python
# Visualization of Shopping Preferences
plt.figure(figsize=(8, 5))
sns.countplot(
    x="Shopping_Preference",
    data=data_cleaned,
    order=data_cleaned["Shopping_Preference"].value_counts().index,
    palette="muted",
)
plt.title("Shopping Preferences (Online vs In-store)")
plt.xlabel("Preference")
plt.ylabel("Count")
plt.show()

```

    C:\Users\HP\AppData\Local\Temp\ipykernel_12596\555808637.py:3: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `x` variable to `hue` and set `legend=False` for the same effect.
    
      sns.countplot(
    


    
![png](output_11_1.png)
    



```python
# Visualization of Confidence Frequency
plt.figure(figsize=(8, 5))
sns.countplot(
    x="Confidence_Frequency",
    data=data_cleaned,
    order=data_cleaned["Confidence_Frequency"].value_counts().index,
    palette="pastel",
)
plt.title("Confidence Frequency in Style")
plt.xlabel("Frequency")
plt.ylabel("Count")
plt.show()
```

    C:\Users\HP\AppData\Local\Temp\ipykernel_12596\1512439924.py:3: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `x` variable to `hue` and set `legend=False` for the same effect.
    
      sns.countplot(
    


    
![png](output_12_1.png)
    



```python
# Import necessary libraries for machine learning
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, accuracy_score
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline

# Define target and features
# Example: Predicting Style Satisfaction
target = "Style_Satisfaction"
X = data_cleaned.drop(columns=[target, "Full_Name", "Timestamp"], errors="ignore")
y = data_cleaned[target]

# Handle missing values (if applicable)
X = X.fillna("Unknown")
y = y.fillna(y.mode()[0])

# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Identify categorical and numerical columns
categorical_columns = X.select_dtypes(include=["object"]).columns
numerical_columns = X.select_dtypes(include=["number"]).columns

# Preprocessing
# Encode categorical features and scale numerical features
preprocessor = ColumnTransformer(
    transformers=[
        ("num", StandardScaler(), numerical_columns),
        ("cat", OneHotEncoder(handle_unknown="ignore"), categorical_columns),
    ]
)

# Build a pipeline for Decision Tree
dt_pipeline = Pipeline(
    steps=[
        ("preprocessor", preprocessor),
        ("classifier", DecisionTreeClassifier(random_state=42)),
    ]
)

# Train Decision Tree model
dt_pipeline.fit(X_train, y_train)

# Predict using the Decision Tree model
y_pred_dt = dt_pipeline.predict(X_test)

# Evaluate Decision Tree model
print("Decision Tree Classification Report:")
print(classification_report(y_test, y_pred_dt))
print("Accuracy:", accuracy_score(y_test, y_pred_dt))

# Build a pipeline for Random Forest
rf_pipeline = Pipeline(
    steps=[
        ("preprocessor", preprocessor),
        ("classifier", RandomForestClassifier(random_state=42, n_estimators=100)),
    ]
)

# Train Random Forest model
rf_pipeline.fit(X_train, y_train)

# Predict using the Random Forest model
y_pred_rf = rf_pipeline.predict(X_test)

# Evaluate Random Forest model
print("\nRandom Forest Classification Report:")
print(classification_report(y_test, y_pred_rf))
print("Accuracy:", accuracy_score(y_test, y_pred_rf))

# Visualize Feature Importance for Random Forest (Optional)
if hasattr(rf_pipeline.named_steps["classifier"], "feature_importances_"):
    feature_names = (
        numerical_columns.tolist()
        + list(preprocessor.named_transformers_["cat"].get_feature_names_out())
    )
    feature_importances = rf_pipeline.named_steps["classifier"].feature_importances_
    feature_importance_df = pd.DataFrame(
        {"Feature": feature_names, "Importance": feature_importances}
    ).sort_values(by="Importance", ascending=False)

    # Plot feature importance
    plt.figure(figsize=(10, 6))
    sns.barplot(
        x="Importance", y="Feature", data=feature_importance_df.head(10), palette="viridis"
    )
    plt.title("Top 10 Feature Importances (Random Forest)")
    plt.xlabel("Importance")
    plt.ylabel("Feature")
    plt.show()

```

    Decision Tree Classification Report:
                                                    precision    recall  f1-score   support
    
    Mostly satisfied, but I’d like to explore more       0.00      0.00      0.00         4
               Neutral, I’m unsure if they suit me       0.40      1.00      0.57         2
               Unsatisfied, I want to make changes       0.00      0.00      0.00         0
       Very satisfied, I feel they reflect me well       0.67      0.67      0.67         3
    
                                          accuracy                           0.44         9
                                         macro avg       0.27      0.42      0.31         9
                                      weighted avg       0.31      0.44      0.35         9
    
    Accuracy: 0.4444444444444444
    

    D:\New folder\Lib\site-packages\sklearn\metrics\_classification.py:1509: UndefinedMetricWarning: Precision is ill-defined and being set to 0.0 in labels with no predicted samples. Use `zero_division` parameter to control this behavior.
      _warn_prf(average, modifier, f"{metric.capitalize()} is", len(result))
    D:\New folder\Lib\site-packages\sklearn\metrics\_classification.py:1509: UndefinedMetricWarning: Recall is ill-defined and being set to 0.0 in labels with no true samples. Use `zero_division` parameter to control this behavior.
      _warn_prf(average, modifier, f"{metric.capitalize()} is", len(result))
    D:\New folder\Lib\site-packages\sklearn\metrics\_classification.py:1509: UndefinedMetricWarning: Precision is ill-defined and being set to 0.0 in labels with no predicted samples. Use `zero_division` parameter to control this behavior.
      _warn_prf(average, modifier, f"{metric.capitalize()} is", len(result))
    D:\New folder\Lib\site-packages\sklearn\metrics\_classification.py:1509: UndefinedMetricWarning: Recall is ill-defined and being set to 0.0 in labels with no true samples. Use `zero_division` parameter to control this behavior.
      _warn_prf(average, modifier, f"{metric.capitalize()} is", len(result))
    D:\New folder\Lib\site-packages\sklearn\metrics\_classification.py:1509: UndefinedMetricWarning: Precision is ill-defined and being set to 0.0 in labels with no predicted samples. Use `zero_division` parameter to control this behavior.
      _warn_prf(average, modifier, f"{metric.capitalize()} is", len(result))
    D:\New folder\Lib\site-packages\sklearn\metrics\_classification.py:1509: UndefinedMetricWarning: Recall is ill-defined and being set to 0.0 in labels with no true samples. Use `zero_division` parameter to control this behavior.
      _warn_prf(average, modifier, f"{metric.capitalize()} is", len(result))
    

    
    Random Forest Classification Report:
                                                    precision    recall  f1-score   support
    
    Mostly satisfied, but I’d like to explore more       0.50      0.50      0.50         4
               Neutral, I’m unsure if they suit me       0.00      0.00      0.00         2
       Very satisfied, I feel they reflect me well       0.25      0.33      0.29         3
    
                                          accuracy                           0.33         9
                                         macro avg       0.25      0.28      0.26         9
                                      weighted avg       0.31      0.33      0.32         9
    
    Accuracy: 0.3333333333333333
    

    C:\Users\HP\AppData\Local\Temp\ipykernel_12596\780905939.py:87: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `y` variable to `hue` and set `legend=False` for the same effect.
    
      sns.barplot(
    


    
![png](output_13_4.png)
    



```python

```


```python

```
